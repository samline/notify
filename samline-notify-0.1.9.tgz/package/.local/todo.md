# Todo

## Instrucción Para La IA

Este archivo es el registro de tareas pendientes del proyecto.

La IA debe revisarlo para saber qué trabajo quedó explícitamente pendiente por decisión del usuario.

## Regla De Uso

Solo deben agregarse elementos a este archivo cuando el usuario indique de forma explícita que algo queda pendiente, que debe hacerse después, que es una mejora futura o que existe un error por corregir más adelante.

La IA no debe inventar pendientes ni convertir sugerencias implícitas en tareas abiertas sin confirmación del usuario.

Si la IA anota en memoria de sesión un pendiente confirmado por el usuario, también debe registrarlo aquí en la misma tarea o antes de cerrar la sesión para que no dependa de memoria efímera.

## Qué Debe Guardarse Aquí

1. tareas pendientes solicitadas por el usuario
2. mejoras a futuro indicadas expresamente
3. bugs por corregir más adelante
4. refactors aplazados por decisión del usuario
5. ideas aprobadas para una fase posterior

## Formato Recomendado Para Nuevos Ítems

Usar bloques breves con esta estructura:

### Título

- estado: pendiente
- origen: solicitud explícita del usuario
- contexto: resumen corto del motivo
- siguiente acción: qué habría que hacer cuando se retome

## Estado Actual

Actualmente no hay pendientes operativos registrados en este archivo.

### Enforced action

- Pre-task read enforcement

- estado: pendiente
- origen: auditoría interna tras iniciar implementación sin leer `agent-index.md`
- contexto: asegurar que la IA lea `.local/agent-index.md` antes de comenzar tareas futuras
- siguiente acción: implementar un pequeño checklist en el flujo operativo (manual o automatizado) para verificar lectura de `agent-index.md` y confirmar en la sesión.

Cuando el usuario deje tareas explícitamente pendientes, deben añadirse aquí.
